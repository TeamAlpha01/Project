import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tac-dashboard',
  templateUrl: './tac-dashboard.component.html',
  styleUrls: ['./tac-dashboard.component.css']
})
export class TacDashboardComponent implements OnInit {

  title ='Dashboard'

  constructor() { }

  ngOnInit(): void {
  }

}
